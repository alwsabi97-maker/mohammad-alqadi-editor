package com.mohammad.alqadi.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    EditText teacherName, schoolName, testName, questionText, choiceA, choiceB, choiceC, choiceD, questionMark;
    Spinner gradeSpinner, subjectSpinner, questionTypeSpinner, fontSpinner;
    LinearLayout questionsContainer;
    TextView questionsTitle, totalMarks;
    ArrayList<String> questions = new ArrayList<>();
    SharedPreferences prefs;
    Uri selectedImage;

    final String[] grades = {"اختر الصف","الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع","الثامن","التاسع",
            "الأول الثانوي","الثاني الثانوي","الثالث الثانوي"};
    final String[] subjects = {"اختر المادة","اللغة العربية","الرياضيات","العلوم","اللغة الإنجليزية","الدراسات الاجتماعية",
            "التربية الإسلامية","الحاسوب","الفيزياء","الكيمياء","الأحياء"};
    final String[] types = {"اختيار من متعدد","صح أو خطأ","أكمل الفراغ","سؤال مقالي","وصل","رتب","تعريف/مصطلح"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("editor_data", MODE_PRIVATE);

        teacherName = findViewById(R.id.teacherName);
        schoolName = findViewById(R.id.schoolName);
        testName = findViewById(R.id.testName);
        questionText = findViewById(R.id.questionText);
        choiceA = findViewById(R.id.choiceA);
        choiceB = findViewById(R.id.choiceB);
        choiceC = findViewById(R.id.choiceC);
        choiceD = findViewById(R.id.choiceD);
        questionMark = findViewById(R.id.questionMark);

        gradeSpinner = findViewById(R.id.gradeSpinner);
        subjectSpinner = findViewById(R.id.subjectSpinner);
        questionTypeSpinner = findViewById(R.id.questionTypeSpinner);
        fontSpinner = findViewById(R.id.fontSpinner);

        questionsContainer = findViewById(R.id.questionsContainer);
        questionsTitle = findViewById(R.id.questionsTitle);
        totalMarks = findViewById(R.id.totalMarks);

        setup(gradeSpinner, grades);
        setup(subjectSpinner, subjects);
        setup(questionTypeSpinner, types);
        setup(fontSpinner, new String[]{"الافتراضي","نسخ","رقعة","ثلث","كلاسيكي"});

        teacherName.setText(prefs.getString("teacher", ""));
        schoolName.setText(prefs.getString("school", ""));
        testName.setText(prefs.getString("test", ""));

        findViewById(R.id.saveButton).setOnClickListener(v -> save());
        findViewById(R.id.addQuestionButton).setOnClickListener(v -> add());
        findViewById(R.id.addImageButton).setOnClickListener(v -> chooseImage());
        findViewById(R.id.boldButton).setOnClickListener(v ->
                questionText.setTypeface(questionText.getTypeface(), Typeface.BOLD));

        findViewById(R.id.sizeButton).setOnClickListener(v -> {
            float size = questionText.getTextSize() / getResources().getDisplayMetrics().scaledDensity;
            questionText.setTextSize(size >= 22 ? 16 : 22);
        });

        findViewById(R.id.alignButton).setOnClickListener(v -> {
            int right = Gravity.TOP | Gravity.RIGHT;
            questionText.setGravity(questionText.getGravity() == right
                    ? (Gravity.TOP | Gravity.CENTER_HORIZONTAL) : right);
        });

        fontSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                Typeface tf;
                switch (pos) {
                    case 1: tf = Typeface.create("serif", Typeface.NORMAL); break;
                    case 2: tf = Typeface.create("sans-serif", Typeface.NORMAL); break;
                    case 3: tf = Typeface.create("serif", Typeface.BOLD); break;
                    case 4: tf = Typeface.create("sans-serif-light", Typeface.NORMAL); break;
                    default: tf = Typeface.DEFAULT;
                }
                questionText.setTypeface(tf);
            }
        });

        findViewById(R.id.clearButton).setOnClickListener(v -> clear());
        findViewById(R.id.resetButton).setOnClickListener(v -> {
            questions.clear();
            clear();
            refresh();
            saveQuestions();
        });
        findViewById(R.id.bankButton).setOnClickListener(v -> showBank());
        findViewById(R.id.duplicateButton).setOnClickListener(v -> {
            if (!questions.isEmpty()) {
                questions.add(questions.get(questions.size() - 1));
                refresh();
            }
        });
        findViewById(R.id.exportButton).setOnClickListener(v -> exportText());
        findViewById(R.id.saveFullButton).setOnClickListener(v -> {
            save();
            saveQuestions();
            Toast.makeText(this, "تم حفظ الاختبار كاملًا", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.loadFullButton).setOnClickListener(v -> {
            loadQuestions();
            Toast.makeText(this, "تمت استعادة الاختبار المحفوظ", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.previewButton).setOnClickListener(v -> preview());

        loadQuestions();
    }

    void setup(Spinner spinner, String[] values) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, values) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
                t.setTextSize(15);
                return t;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    void save() {
        prefs.edit()
                .putString("teacher", teacherName.getText().toString())
                .putString("school", schoolName.getText().toString())
                .putString("test", testName.getText().toString())
                .apply();
        Toast.makeText(this, "تم حفظ بيانات الاختبار على الهاتف", Toast.LENGTH_SHORT).show();
    }

    void chooseImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 99);
    }

    void add() {
        String q = questionText.getText().toString().trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "اكتب نص السؤال أولاً", Toast.LENGTH_SHORT).show();
            return;
        }

        String type = questionTypeSpinner.getSelectedItem().toString();
        String options = "";
        if ("اختيار من متعدد".equals(type)) {
            String a = choiceA.getText().toString().trim();
            String b = choiceB.getText().toString().trim();
            String c = choiceC.getText().toString().trim();
            String d = choiceD.getText().toString().trim();
            if (!a.isEmpty() || !b.isEmpty() || !c.isEmpty() || !d.isEmpty()) {
                options = "\nأ) " + a + "   ب) " + b + "   ج) " + c + "   د) " + d;
            }
        }

        String mark = questionMark.getText().toString().trim();
        if (mark.isEmpty()) mark = "1";

        String imageNote = selectedImage != null ? " [صورة مرفقة]" : "";
        questions.add(type + " — " + q + options + "  (الدرجة: " + mark + ")" + imageNote);
        clear();
        refresh();
    }

    void clear() {
        questionText.setText("");
        choiceA.setText("");
        choiceB.setText("");
        choiceC.setText("");
        choiceD.setText("");
        questionMark.setText("");
        selectedImage = null;
    }

    void refresh() {
        questionsContainer.removeAllViews();
        questionsTitle.setText("الأسئلة: " + questions.size());

        int marks = 0;
        Pattern pattern = Pattern.compile("الدرجة: (\\d+)");
        for (String x : questions) {
            Matcher m = pattern.matcher(x);
            if (m.find()) {
                try { marks += Integer.parseInt(m.group(1)); } catch (Exception ignored) {}
            }
        }
        if (totalMarks != null) totalMarks.setText("إجمالي الدرجات: " + marks);

        for (int i = 0; i < questions.size(); i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(14, 14, 14, 8);
            row.setBackgroundResource(R.drawable.bg_card);

            TextView t = new TextView(this);
            t.setText((i + 1) + ". " + questions.get(i));
            t.setTextSize(16);
            t.setTextColor(Color.rgb(23, 59, 87));
            t.setGravity(Gravity.RIGHT);
            row.addView(t, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);

            Button edit = new Button(this);
            edit.setText("تعديل");
            Button del = new Button(this);
            del.setText("حذف");

            actions.addView(edit, new LinearLayout.LayoutParams(0, -2, 1));
            actions.addView(del, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(actions);

            edit.setOnClickListener(v -> {
                String old = questions.get(index);
                String text = old.replaceFirst("^[^—]+— ", "");
                int optionPos = text.indexOf("\nأ) ");
                if (optionPos >= 0) text = text.substring(0, optionPos);
                int markPos = text.lastIndexOf("  (الدرجة:");
                if (markPos >= 0) text = text.substring(0, markPos);
                questionText.setText(text.trim());
                questions.remove(index);
                refresh();
            });

            del.setOnClickListener(v -> {
                questions.remove(index);
                refresh();
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, 10);
            questionsContainer.addView(row, lp);
        }

        saveQuestions();
    }

    void saveQuestions() {
        StringBuilder b = new StringBuilder();
        for (String q : questions) {
            if (b.length() > 0) b.append('\u0001');
            b.append(q.replace("\u0001", " "));
        }
        prefs.edit().putString("questions", b.toString()).apply();
    }

    void loadQuestions() {
        questions.clear();
        String raw = prefs.getString("questions", "");
        if (!raw.isEmpty()) {
            String[] saved = raw.split("\\u0001", -1);
            for (String q : saved) if (!q.isEmpty()) questions.add(q);
        }
        refresh();
    }

    String buildExportText() {
        StringBuilder b = new StringBuilder();
        b.append("محرر محمد القاضي الشامل\n");
        b.append(testName.getText()).append("\n");
        b.append("المعلم: ").append(teacherName.getText()).append("\n");
        b.append("المدرسة: ").append(schoolName.getText()).append("\n\n");
        for (int i = 0; i < questions.size(); i++) {
            b.append(i + 1).append(". ").append(questions.get(i)).append("\n\n");
        }
        return b.toString();
    }

    void preview() {
        new AlertDialog.Builder(this)
                .setTitle("معاينة الاختبار")
                .setMessage(buildExportText())
                .setPositiveButton("إغلاق", null)
                .show();
    }

    void showBank() {
        StringBuilder b = new StringBuilder();
        b.append("بنك الأسئلة المحلي\n\n");
        if (questions.isEmpty()) {
            b.append("لا توجد أسئلة محفوظة بعد.");
        } else {
            for (int i = 0; i < questions.size(); i++) {
                b.append(i + 1).append(". ").append(questions.get(i)).append("\n\n");
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("بنك الأسئلة")
                .setMessage(b.toString())
                .setPositiveButton("إغلاق", null)
                .show();
    }

    void exportText() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, buildExportText());
        startActivity(Intent.createChooser(send, "مشاركة الاختبار"));
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 99 && resultCode == RESULT_OK && data != null) {
            selectedImage = data.getData();
            if (selectedImage != null) {
                Toast.makeText(this, "تم اختيار الصورة للسؤال", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
